 const ProductFilterAbleFileds = ['searchTerm', 'tag', 'category_id', 'subCategoryItem_id', 'brand_id' ];

 const ProductSearchableFields = ['searchTerm', 'tag', 'title', 'brand_title',  'category_title'];


module.exports = {

    ProductFilterAbleFileds,
    ProductSearchableFields

}