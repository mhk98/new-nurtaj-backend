const subCategoryItemFilterAbleFileds = ['searchTerm', 'tag', 'category_id', 'subCategoryItem_id', 'brand_id' ];

const subCategoryItemSearchableFields = ['searchTerm', 'tag', 'title', 'brand_title', 'category_title'];


module.exports = {

    subCategoryItemFilterAbleFileds,
    subCategoryItemSearchableFields

}